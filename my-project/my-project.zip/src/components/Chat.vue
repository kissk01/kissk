<template>
	<div id="chat">
		<div id="chatLogin">
			<form action="/" @submit="login">
				<input type="text" v-model="username" placeholder="User name">
				<input type="submit" value="Submit">
			</form>
		</div>
	</div>
</template>

<script>
//http://frontend-test-server.prmrgt.com/
	
	export default {
	    data() {
	        return {
	            socket: null,
	            loggedIn: false,
	            username: ''
	        }
	    },
	    sockets:{
		    connect: function(){
		      console.log('socket connected')
		    },
		    customEmit: function(val){
		      console.log('this method was fired by the socket server. eg: io.emit("customEmit", data)')
		    }
		},
	    /*components: { ChatBox },
	    */
	    mounted() {
    		console.log("ready")
    		
        	//this.socket = io();
        },
	    methods: {
	        login(event) {
	            event.preventDefault()
	            this.loggedIn = true
	            console.log(" logged in ", this.username)
	            this.socket.emit('user logged in', this.username)
	        }
	    }
	    /*computed: {
	        isAdmin() {
	            return this.username == 'admin'
	        }
	    }*/
	}
</script>